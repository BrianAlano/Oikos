import { useState } from 'react';
import LandingPage from './LandingPage';
import TimekeepingApp from './app/App';

export default function App() {
  const [page, setPage] = useState<'landing' | 'timekeeping'>('landing');

  if (page === 'timekeeping') {
    return (
      <div style={{ minHeight: '100vh' }}>
        <TimekeepingApp />
        <button
          type="button"
          onClick={() => setPage('landing')}
          style={{
            position: 'fixed',
            top: 16,
            left: 16,
            zIndex: 1000,
            background: '#111827',
            color: '#fff',
            border: 'none',
            borderRadius: 8,
            padding: '8px 12px',
            fontSize: 13,
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,.18)',
          }}
        >
          ← Back to Oikos
        </button>
      </div>
    );
  }

  return <LandingPage onLaunch={() => setPage('timekeeping')} />;
}
